import java.sql.*;
import java.rmi.*;
import java.io.*;
import java.util.*; 
import java.util.Vector.*;
import java.lang.*;
import java.rmi.registry.*;

public class client
{
	static String name1,name2,name3;
	
	public static void  main(String args[])
	{
	client c=new client();
	BufferedReader b =new BufferedReader(new InputStreamReader(System.in));
	try
	 {  Registry r1 = LocateRegistry.getRegistry ("localhost", 1050);    
	              DBInterface DI=(DBInterface) r1.lookup("DBServ");
	
	              int ch;
	do
	              {
	                                System.out.println("1.send input stings\n2.Disp$\nEnter ur choice");
	                                ch = Integer.parseInt(b.readLine());
	                                switch(ch)
	                                {
	                              case  1:
	                                      System.out.println(" \n Enter first string:");
	                              name1=b.readLine(); 
	                                   System.out.println(" \n Enter second string:");
	                              name2=b.readLine(); 
	                              name3=DI.input(name1,name2);
	                              break;
	                              case  2:          
	                                System.out.println("\n Concatenated String is : ");
	                              int i=0;
	                                        System.out.println(" " +name3+"");
	                                        break;
	                                }
	              } while (ch>0);  
	                                         
	              }
	                    catch (Exception e)
	                             {
	                     System.out.println("ERROR: " +e.getMessage());
	                             }
	}
}
