import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.util.Vector; 
interface DBInterface extends Remote
{
public String input(String name1 ,String name2 ) throws RemoteException;
}


public class server extends UnicastRemoteObject implements DBInterface

{
int flag=0,n,i,j;
String name3;  
ResultSet r;

	protected server() throws RemoteException 
        {
		super();
		try
	    { System.out.println("Initializing...\nServer Ready");
	    }
	catch (Exception e)
	    {  System.out.println("Something Went Wrong: "+e.getMessage());
	    }
	}
	public static void main (String arg[]) throws AccessException, RemoteException{
		try
		{ 
		 server rs=new server();
		    LocateRegistry.createRegistry(1050).rebind("DBServ",rs);
		}
		catch(Exception e)
		{
		System.out.println("Something Went Wrong: "+e.getMessage());
		}
		}
	@Override
	public String input(String name1, String name2) throws RemoteException {
		try
		{
		name3=name1.concat(name2);
		           }             
		catch(Exception e)
		          {
		           System.out.println("Something went Wrong: "+e.getMessage());
		          }
		return name3;
	}

}
